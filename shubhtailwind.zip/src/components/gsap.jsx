import React from 'react'

const gsap = () => {
  return (
    <>
    <div className='box'>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam aliquid voluptate in eveniet nemo assumenda nihil expedita vitae cumque? Recusandae, quam ipsam nobis blanditiis obcaecati repudiandae in nostrum molestiae sit.</p>
    </div>
    </>
  )
}

export default gsap