import React from 'react'
import logo from '../assets/images/logo.png';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <>
    <header className='w-full flex justify-between py-4 z-10 absolute top-0 left-0' >
      <div className='container  mx-auto px-[65px]'>
    <nav className=' flex justify-between items-center'>
      <div className='logo w-[194px] h-auto'>
        <img src={logo} alt='image'/>
      </div>
      <div className='flex justify-between gap-[37px]'>
      <ul className='flex justify-between gap-[37px] items-center'>
        <Link to="/home" className='text-white hover:text-[#852438]'>Home</Link>
        <Link to="/" className='text-white hover:text-[#852438]'>About Us</Link>
        <Link to="/" className='text-white hover:text-[#852438]'>Our Projects</Link>
        <Link to="/" className='text-white hover:text-[#852438]'>Contact</Link>
      </ul>
   {/* Call to Action Button */}
   <button className='bg-[#852438] text-white px-[20px] py-[10px] rounded-[30px] hover:bg-[#DABF70] hover:shadow-lg hover:scale-105 transition-all duration-300 ease-in-out'>Call Now</button>
   </div>
    </nav>
    </div>
    </header>
    </>
  )
}

export default Header;